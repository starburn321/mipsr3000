Download a file from
http://www.opencores.org/projects.cgi/web/mips/gccmips_elf.zip

Extract it and copy files listed below in this folder.

cywin1.dll
as.exe
gcc.exe
ld.exe
objdump.exe

The usage of conver_sp.exe genmif.exe and gensim.exe please refrence to course code. 

Liwei 
2007-8-29

