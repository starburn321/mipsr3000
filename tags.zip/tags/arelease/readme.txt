Please run REMOVEDIR.BAT and then enter 'Y' in 
windows system to remove these empty folders listed below.

dbe 
verilog
tools 
dbe 
tools_source_code

I created these empty folders but then couldnot 
delect them via WINCVS,Sorry...

To simulate in MODELSIM,please copy this folder to disk D:\.Then open MODELSIM project in  D:\mip789\bench\modelsim. 

Anything about this cores please contact me via 
Email:mcupro@opencores.org or mcupro@163.com

Enjoy MIPS789,

Liwei 
2007-11-1